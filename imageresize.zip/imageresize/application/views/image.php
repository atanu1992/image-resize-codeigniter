<!DOCTYPE html>
<html>
<head>
	<title>Image</title>
</head>
<body>
<form action="<?php echo base_url('ImageController/index'); ?>" method="post" enctype="multipart/form-data">
  First name: <input type="file" name="image"><br>
  <input type="submit" value="Submit" name="submit">
</form>
</body>
</html>
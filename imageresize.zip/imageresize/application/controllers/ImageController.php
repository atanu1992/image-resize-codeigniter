<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class ImageController extends CI_Controller {

	public function __construct() {
		parent::__construct();
	}


	public function uploadImage($file,$orgPath,$thumbPath) {



				$this->load->library('image_lib');
				$new_name = time().$file['name'];
				$config['file_name'] 	   = $new_name;
			    $config['upload_path']     = $_SERVER['DOCUMENT_ROOT']."/imageresize/uploads/gallery/".$orgPath; 
		        $config['allowed_types']   = 'jpg|png';
		        // echo "<pre>"; print_r($config); die;
		        $this->load->library('upload', $config);
		        if ( ! $this->upload->do_upload('image')) {
	                $error = array('error' => $this->upload->display_errors());
	                return $error;
		        }
		        else {
	                $data = array('upload_data' => $this->upload->data()); // here orginal image is uploaded
					$configer =  array(
					'image_library'   => 'gd2',
					'source_image'    =>  $data['upload_data']['full_path'], // fetching orginal image where it is saved just right above
					'create_thumb'	  =>  TRUE,
					'new_image'		  =>  $_SERVER['DOCUMENT_ROOT']."/imageresize/uploads/gallery/".$thumbPath, // path of new resize image where resized image will be uploaded
					'maintain_ratio'  =>  TRUE,
					'width'           =>  250,
					'height'          =>  250,
					);
					$this->image_lib->clear();
					$this->image_lib->initialize($configer);
					if($this->image_lib->resize()){
						return $this->image_lib;
					}else{
						return $this->image_lib->display_errors();
					}
		        }
	}


	public function index() {
		$submit = $this->input->post('submit');
			if($submit == 'Submit') {
				$orginalPath = 'original'; // path of orginal image
				$thumbnailPath = 'thumbnail'; // path of thumbnail image
				$aboutImage = $this->uploadImage($_FILES['image'],$orginalPath,$thumbnailPath);
				echo "<pre>"; print_r($aboutImage);
			}
		$this->load->view('image');
	}

}

/* End of file ImageController.php */
/* Location: ./application/controllers/ImageController.php */

?>